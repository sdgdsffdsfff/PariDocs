# Pack 外部库
>例如使用一些zend或者其它框架的外部库
引用方法 Pack\XX\XXX\XX