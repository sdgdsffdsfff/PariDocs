<?php
namespace Utils\Uploadtor;

class Image
{
    protected static $validatorOption = array(
        'minCount' => 1,
        'maxCount' => 10,
        'maxSize' => 5242800,
        'allowExt' => array('jpg', 'jpeg', 'png', 'gif')
    );

    public static function upload($files = null, $basedir = 'temp', array $validatorOption = array())
    {
        $file_adapter = new \Zend\File\Transfer\Adapter\Http();

        $destination = PUBLIC_PATH . '/data/upload/' . $basedir . '/' . date("Y") . '/' . date("m") . '/' . date("d");
        if (!is_dir($destination)) {
            mkdir($destination, 0777, 1);
        }
        $file_adapter->setDestination($destination);
        
        $validatorOption = array_merge(self::$validatorOption, $validatorOption);
        $file_adapter = new \Zend\File\Transfer\Adapter\Http();
        $file_adapter->addValidator('Extension', false, $validatorOption['allowExt'])
                     ->addValidator('Size', false, array('max' => $validatorOption['maxSize']))
                     ->addValidator('Count', false, array('min' => $validatorOption['minCount'], 'max' => $validatorOption['maxCount']));
        
        $renameArr = array();
        foreach ($file_adapter->getFileInfo($files) as $file => $fileInfo) {
            $file_extension = pathinfo($fileInfo['name'], PATHINFO_EXTENSION);
            !empty($file_extension) && $file_extension = '.' . $file_extension;
            do {    
                $target = $destination . '/' . uniqid() . $file_extension;
            } while (file_exists($target));
            $renameArr[] = array('source' => $fileInfo['tmp_name'], 'target' => $target);
        }
        $file_adapter->addFilter('Rename', $renameArr);

        if (!$file_adapter->receive($files)) {
            return array('status' => 0, 'info' => current($file_adapter->getMessages()), 'paths' => array());
        }
        
        $paths = array();
        foreach ($file_adapter->getFileInfo($files) as $file => $fileInfo) {
            $path = ltrim($fileInfo['tmp_name'], PUBLIC_PATH . '/');
            $file_info[$file][] = array(
                'realpath' => $fileInfo['tmp_name'],
                'path' => $path
            );
        }

        return array('status' => 1, 'info' => 'success', 'paths' => $file_info);
    }
}
